﻿using System.ComponentModel.Design;

namespace Proyecto_01_Programación
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Proyecto Práctico No. 1 \n");

            //Primera parte

            Console.WriteLine("Bienvenido! gracias por elegirnos.");

            Console.WriteLine("\nCodigos para las estaciones: \n51 - Estación Javier\n61 - Estacion Trébol\n71 - Estación Don Bosco\n82 - Estación Plaza Municipal\n");
            Console.WriteLine("Ingrese el codigo de su estacion de partida");

            int EstacionOrigen = 0;
            bool Condicion = false;

            while (Condicion == false)
            {

                EstacionOrigen = Convert.ToInt32(Console.ReadLine());

                if (EstacionOrigen == 51 || EstacionOrigen == 61 || EstacionOrigen == 71 || EstacionOrigen == 82)
                {
                    Condicion = true;
                }
                else
                {
                    Console.WriteLine("\nERROR. Por favor ingrese una estacion valida");
                    Condicion = false;
                }

            }

            //Destino

            bool OtroViaje = false;

            double TiempoTotal = 0;
            double PrecioTotal = 0;

            do
            {
                bool condicion2 = false;
                int EstacionDestino = 0;
                double km = 0;

                while (condicion2 == false)
                {
                    Console.WriteLine("\nIngrese el codigo de su estacion de destino");
                    EstacionDestino = Convert.ToInt32(Console.ReadLine());

                    if (EstacionOrigen == 51)
                    {
                        if (EstacionDestino == 61)
                        {
                            condicion2 = true;
                            km = 14;
                            break;
                        }
                        else if (EstacionDestino == 71) //EstacionDestino puede ser 71 u 82
                        {
                            condicion2 = true;
                            km = 28;
                            break;
                        }

                    }

                    if (EstacionOrigen == 71)
                    {
                        if (EstacionDestino == 82)
                        {
                            condicion2 = true;
                            km = 13;
                            break;
                        }
                    }

                    if (EstacionOrigen == 61)
                    {
                        if (EstacionDestino == 51)
                        {
                            condicion2 = true;
                            km = 7;
                            break;
                        }
                    }

                    if (EstacionOrigen == 82)
                    {
                        if (EstacionDestino == 51)
                        {
                            condicion2 = true;
                            km = 21;
                            break;
                        }
                    }

                    //Si se ingresa un error no valido
                    if (condicion2 == false)
                    {
                        Console.WriteLine("\nERROR. Por favor ingrese un codigo valido");
                    }
                }

                //Recopilacion de datos

                bool PFecha = false;
                bool PDia = false;
                bool PMes = false;
                Console.WriteLine("\nA continuacion ingresara la fecha en que usara nuestro servicio...");
                do
                {

                    do
                    {
                        Console.WriteLine("Ingrese el dia de su viaje:");
                        int Dia = Convert.ToInt32(Console.ReadLine());

                        if (Dia > 0 && Dia <= 31)
                        {
                            PDia = true;
                        }
                        else
                        {
                            Console.WriteLine("ERROR. Ingrese un dia valido");
                        }
                    } while (PDia == false);

                    do
                    {
                        Console.WriteLine("Ingrese el mes de su viaje en forma de numeros (1 al 12):");
                        int Mes = Convert.ToInt32(Console.ReadLine());

                        if (Mes > 0 && Mes <= 12)
                        {
                            PMes = true;
                        }
                        else
                        {
                            Console.WriteLine("ERROR. Ingrese un mes valido");
                        }
                    } while (PMes == false);

                    //Condicion final

                    if (PDia == true && PMes == true)
                    {
                        PFecha = true;
                        //VARIABLES: Dia, Mes
                    }

                } while (PFecha == false);

                //Pregunta de la edad
                Console.WriteLine("\nIngrese su edad");
                int Edad = Convert.ToInt32(Console.ReadLine());


                //Pregunta si esta embarazada...
                Console.WriteLine("\nIndique si se encuentra en estado de gestación ingresando <si> o <no>"); 
                string Respuesta = Console.ReadLine().ToLower();
                bool Embarazada = false;
                if (Respuesta == "si")
                {
                    Embarazada = true;
                }


                //Viaje con un niño menor a 3 años
                Console.WriteLine("\nIndique si viajara con un niño menor a 3 años ingresando <si> o <no>");
                Respuesta = Console.ReadLine().ToLower();
                bool Niño = false;
                if (Respuesta == "si")
                {
                    Niño = true;
                }

                //Segunda parte

                //Casos de descuentos
                bool DescuentoGratis = false;
                if (Embarazada == true || Niño == true)
                {
                    DescuentoGratis = true;
                }

                //Determinacion de precios

                double precio = 0;
                double descuento = 1;

                bool PCalculo = false;
                while (PCalculo == false)
                {
                    if (DescuentoGratis == true)
                    {
                        precio = 0;
                        break;
                    }

                    if (Edad >= 15 && Edad <= 25)
                    {
                        descuento = 0.79;
                    }

                    //Operaciones
                    if (km <= 10)
                    {
                        precio = 0.07 * descuento;
                        PrecioTotal += precio;
                        PCalculo = true;
                    }
                    else
                    {
                        precio = descuento * (0.07 + ((km - 10) * 0.02));
                        PrecioTotal += precio;
                        PCalculo = true;
                    }
                }

                //Determinacion de tiempo
                double tiempo = km / 40;
                TiempoTotal += tiempo;

                //Salidas del sistema

                //Nombre de las estacion de partida
                string origen = "";
                if (EstacionOrigen == 51)
                {
                    origen = "Estación Javier";
                }
                else if (EstacionOrigen == 61)
                {
                    origen = "Estación Trébol";
                }
                else if (EstacionOrigen == 71)
                {
                    origen = "Estación Don Bosco";
                }
                else if (EstacionOrigen == 82)
                {
                    origen = "Estación Plaza Municipal";
                }

                //Nombre de la estacion de destino
                string destino = "";
                if (EstacionDestino == 61)
                {
                    destino = "Estación Trébol";
                }
                else if (EstacionDestino == 71) //Puede ser 71 u 82
                {
                    destino = "Estación Don Bosco";
                }
                else if (EstacionDestino == 82)
                {
                    destino = "Estación Plaza Municipal";
                }
                else if (EstacionDestino == 51)
                {
                    destino = "Estación Javier";
                }

                //Imprimir
                Console.WriteLine("\nGracias por su compra, su boleto indica lo siguiente:");
                Console.WriteLine($"La ruta que tomara sera de la {origen} a la {destino}");
                Console.WriteLine("El tiempo estimado de su viaje sera de: " + tiempo + " horas");
                Console.WriteLine("El precio de su boleto es: Q." + precio);

                //Otro viaje
                Console.WriteLine("\nGracias por viajar con nosotros!. ¿Desea continuar viajando?, por favor conteste con un <si> para elegir su siguiente destino o un <no> para terminar el programa:"); //Cambiar el ingreso de la respuesta permitiendo mayusculas y minusculas
                string MasViajes = Console.ReadLine().ToLower();

                if (MasViajes == "si")
                {
                    OtroViaje = true;
                    EstacionOrigen = EstacionDestino;
                    Console.Clear();
                }

                else
                OtroViaje = false;
                Console.Clear();


            } while (OtroViaje == true);

            //Impresion final
            Console.WriteLine($"\nEl tiempo total que usted ha viajado es {TiempoTotal} horas");
            Console.WriteLine("Su total gastado en boletos es Q."+PrecioTotal);
        }
    }
}